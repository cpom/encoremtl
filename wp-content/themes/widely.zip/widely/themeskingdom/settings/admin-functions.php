<?php 
	get_template_part(GD_FUNCTIONS . 'admin/theme.php');

	
?>